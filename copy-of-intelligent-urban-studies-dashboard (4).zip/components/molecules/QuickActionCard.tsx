
import React from 'react';
import { QuickActionCardType } from '../../types';
import { Card } from '../atoms/Card';
import { useAppContext } from '../../hooks/useAppContext';

export const QuickActionCard: React.FC<{ action: QuickActionCardType }> = ({ action }) => {
  const { setCurrentPage } = useAppContext();

  const handleClick = () => {
    if (action.page) {
      setCurrentPage(action.page);
    }
  };

  return (
    <Card 
      className={`text-center flex flex-col items-center justify-center transition-all duration-300 cursor-pointer glow-border`}
      onClick={handleClick}
    >
        <div className={`p-4 rounded-xl mb-4 bg-primary/20 text-primary`}>
             {action.icon}
        </div>
        <h4 className="font-bold text-white">{action.title}</h4>
        {action.description && <p className="text-xs text-[#A0A0A0] mt-1">{action.description}</p>}
    </Card>
  );
};