import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';

interface CardProps extends HTMLMotionProps<'div'> {
  children?: React.ReactNode;
  className?: string;
  padding?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = '', padding = 'p-6', ...props }) => {
  return (
    <motion.div
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={`surface-card ${padding} ${className}`}
      {...props}
    >
      {children}
    </motion.div>
  );
};
