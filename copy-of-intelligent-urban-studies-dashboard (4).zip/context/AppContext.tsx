
import React, { createContext, useState, useEffect } from 'react';
import { Page } from '../types';

interface AppContextType {
  isRtl: boolean;
  toggleDirection: () => void;
  isLeftSidebarOpen: boolean;
  setLeftSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
  toggleLeftSidebar: () => void;
  isRightSidebarOpen: boolean;
  setRightSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
  toggleRightSidebar: () => void;
  isChatOpen: boolean;
  setChatOpen: React.Dispatch<React.SetStateAction<boolean>>;
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  handleThemeChange: (hsl: { h: number; s: number; l: number }) => void;
  isRightSidebarCollapsed: boolean;
  toggleRightSidebarCollapse: () => void;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isRtl, setIsRtl] = useState(true);
  const [isLeftSidebarOpen, setLeftSidebarOpen] = useState(false);
  const [isRightSidebarOpen, setRightSidebarOpen] = useState(false);
  const [isChatOpen, setChatOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [isRightSidebarCollapsed, setRightSidebarCollapsed] = useState(false);

  useEffect(() => {
    const handleResize = () => {
        if (window.innerWidth < 1024) {
            setLeftSidebarOpen(false);
            setRightSidebarOpen(false);
            setRightSidebarCollapsed(false);
        } else {
            setLeftSidebarOpen(true);
        }
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // Close sidebars when page changes on mobile
  useEffect(() => {
    if (window.innerWidth < 1024) {
        setLeftSidebarOpen(false);
        setRightSidebarOpen(false);
    } else {
        // Keep left sidebar open by default on desktop, unless it's a page that hides it
        setLeftSidebarOpen(true);
    }
  }, [currentPage])

  const toggleDirection = () => setIsRtl(prev => !prev);
  const toggleLeftSidebar = () => setLeftSidebarOpen(prev => !prev);
  const toggleRightSidebar = () => setRightSidebarOpen(prev => !prev);
  const toggleRightSidebarCollapse = () => {
      if (window.innerWidth >= 1024) {
          setRightSidebarCollapsed(prev => !prev);
      }
  };

  const handleThemeChange = (hsl: { h: number; s: number; l: number }) => {
    document.documentElement.style.setProperty('--color-primary-h', hsl.h.toString());
    document.documentElement.style.setProperty('--color-primary-s', `${hsl.s}%`);
    document.documentElement.style.setProperty('--color-primary-l', `${hsl.l}%`);
  };
  
  const value = {
    isRtl,
    toggleDirection,
    isLeftSidebarOpen,
    setLeftSidebarOpen,
    toggleLeftSidebar,
    isRightSidebarOpen,
    setRightSidebarOpen,
    toggleRightSidebar,
    isChatOpen,
    setChatOpen,
    currentPage,
    setCurrentPage,
    handleThemeChange,
    isRightSidebarCollapsed,
    toggleRightSidebarCollapse,
  };

  return (
    <AppContext.Provider value={value}>
        {children}
    </AppContext.Provider>
    );
};
