
import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  color?: 'primary' | 'green' | 'red' | 'yellow' | 'blue' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  color = 'primary',
  size = 'md',
  className = '',
}) => {
  const baseClasses = 'inline-flex items-center font-semibold rounded-full border badge-bounce';

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-0.5 text-sm',
  };

  const colorClasses = {
    primary: 'bg-gradient-to-br from-purple-500/30 to-blue-500/30 text-purple-200 border-purple-400/50',
    green: 'bg-gradient-to-br from-green-500/30 to-teal-500/30 text-green-200 border-green-400/50',
    red: 'bg-gradient-to-br from-red-500/30 to-orange-500/30 text-red-200 border-red-400/50',
    yellow: 'bg-gradient-to-br from-yellow-500/30 to-amber-500/30 text-yellow-200 border-yellow-400/50',
    blue: 'bg-gradient-to-br from-sky-500/30 to-indigo-500/30 text-sky-200 border-sky-400/50',
    gray: 'bg-gray-500/20 text-gray-300 border-gray-400/50',
  };

  return (
    <span className={`${baseClasses} ${sizeClasses[size]} ${colorClasses[color]} ${className}`}>
      {children}
    </span>
  );
};
