
import React from 'react';
import { NavItemType, StatCardType, QuickActionCardType, ActiveTaskType, RecentActivityType, ChartDataType, CourseType, WalletSummaryType, TransactionType, PersonaType, UserProfileType, VideoType, AchievementType } from './types';
import { Icon } from './components/atoms/Icon';

// --- ICONS (as SVG strings) ---
export const HOME_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" /></svg>`;
export const ADD_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>`;
export const SEARCH_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" /></svg>`;
export const NOTIFICATION_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" /></svg>`;
export const THEME_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.098 19.902a3.75 3.75 0 005.304 0l6.401-6.402a3.75 3.75 0 00-.625-6.25A3.75 3.75 0 006.75 8.25l-2.652 2.652c-.317.317-.475.744-.475 1.175v3.328c0 .43.158.858.475 1.175z" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 12a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" /><path stroke-linecap="round" stroke-linejoin="round" d="M12.75 15.75l-3.75-3.75M16.5 13.5l-3.75-3.75" /></svg>`;
export const LANGUAGE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 016-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C13.18 7.061 14.12 7.5 15 7.5c.879 0 1.76-.29 2.499-.636M12 3v2.25" /></svg>`;
export const CHEVRON_DOWN_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" /></svg>`;
export const CHEVRON_LEFT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" /></svg>`;
export const CHEVRON_RIGHT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" /></svg>`;
export const AI_ASSISTANT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.5 21.75l-.398-1.188a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.188-.398a2.25 2.25 0 001.423-1.423L16.5 15.75l.398 1.188a2.25 2.25 0 001.423 1.423L19.5 18.75l-1.188.398a2.25 2.25 0 00-1.423 1.423z" /></svg>`;
export const BOOK_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-16.512A8.966 8.966 0 0118 3.75c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18c-2.305 0-4.408.867-6 2.292m0-16.512V18" /></svg>`;
export const WORD_COUNT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.125 2.25h-4.5c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125v-9M10.125 2.25c.621 0 1.125.504 1.125 1.125v3.375c0 .621-.504 1.125-1.125 1.125h-1.5c-.621 0-1.125-.504-1.125-1.125v-3.375c0-.621.504-1.125 1.125-1.125h1.5Z" /></svg>`;
export const TRANSLATE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5" /></svg>`;
export const COLLABORATION_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.226a3 3 0 00-4.682 2.72 9.094 9.094 0 003.741.479m7.5-2.226V18a2.25 2.25 0 01-2.25 2.25H8.25A2.25 2.25 0 016 18V6.75A2.25 2.25 0 018.25 4.5h7.5A2.25 2.25 0 0118 6.75v8.25z" /></svg>`;
export const ACTIVITY_PULSE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 12h3m3 0h3m3 0h3m-9 3.75h3m-3-7.5h3m6-3.75h3m-3 7.5h3m-9 3.75h3m-6-11.25L12 3.75l2.25 2.25" /></svg>`;
export const ACTIVE_TASK_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" /></svg>`;
export const CHART_BAR_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>`;
export const MENU_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" /></svg>`;
export const IMAGE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>`;
export const VIDEO_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15.91 11.672a.375.375 0 010 .656l-5.603 3.113a.375.375 0 01-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112z" /></svg>`;
export const ACADEMY_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /><path stroke-linecap="round" stroke-linejoin="round" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222 4 2.222V20" /></svg>`;
export const WALLET_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 9m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3" /></svg>`;
export const USER_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg>`;
export const PERSONA_CHAT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.226a3 3 0 00-4.682 2.72 9.094 9.094 0 003.741.479m7.5-2.226V18a2.25 2.25 0 01-2.25 2.25H8.25A2.25 2.25 0 016 18V6.75A2.25 2.25 0 018.25 4.5h7.5A2.25 2.25 0 0118 6.75v8.25z" /></svg>`;
export const SEND_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>`;
export const MINIMIZE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 12h-15" /></svg>`;
export const MAXIMIZE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" /></svg>`;
export const DOWNLOAD_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>`;
export const DELETE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.067-2.09.921-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" /></svg>`;
export const WRITING_CENTER_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9 5H7a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const TRANSLATOR_PRO_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 21.75 8.25 19.5M10.5 21.75V19.5m0 2.25L12.75 19.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 3v10.5m0 0-3-3m3 3 3-3M3 12h18" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6.345 19.5a9 9 0 0 1 11.31 0" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const TERMINOLOGY_BOOK_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-16.512A8.966 8.966 0 0 1 18 3.75c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18c-2.305 0-4.408.867-6 2.292m0-16.512V18" stroke-linecap="round" stroke-linejoin="round"></path><path d="m14.25 10.5-2.25 2.25-2.25-2.25" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const PLAGIARISM_CHECKER_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 12.75 11.25 15 15 9.75" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10.5 15.75a7.5 7.5 0 0 0 3 0" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const RESEARCH_TOOLKIT_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M4.5 12.75l7.5-7.5 7.5 7.5m-15 6l7.5-7.5 7.5 7.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2 13.5h20" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 21V9" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8.25 4.5a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5h-6a.75.75 0 0 1-.75-.75Z" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const DATA_LAB_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M11.25 3.75v1.5M12 6h.01M12 12h.01M12 18h.01M12 21h.01M4.5 12h1.5m1.5 0h1.5m6 0h-1.5m-1.5 0h-1.5m-1.5 0H12M3 3.75a9 9 0 0 1 18 0v16.5a9 9 0 0 1-18 0V3.75Z" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const DIGITAL_LIBRARY_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M6 21H3.75v-6.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const SURVEYS_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.125 2.25h-4.5c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125v-9M10.125 2.25c.621 0 1.125.504 1.125 1.125v3.375c0 .621-.504 1.125-1.125 1.125h-1.5c-.621 0-1.125-.504-1.125-1.125v-3.375c0-.621.504-1.125 1.125-1.125h1.5Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.75 9.75 13.5 9l3 3-3 3-.75-.75" stroke-linecap="round" stroke-linejoin="round"></path><path d="m12.75 14.25 3-3" stroke-linecap="round" stroke-linejoin="round"></path><path d="m12.75 18.75 3-3" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const AI_CENTER_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M8.25 3.75H19.5M8.25 3.75h.008v.008H8.25V3.75Zm0 3.75h.008v.008H8.25V7.5Zm0 3.75h.008v.008H8.25v-.008Zm0 3.75h.008v.008H8.25v-.008Zm0 3.75h.008v.008H8.25v-.008ZM4.5 3.75h.008v.008H4.5V3.75Zm0 3.75h.008v.008H4.5V7.5Zm0 3.75h.008v.008H4.5v-.008Zm0 3.75h.008v.008H4.5v-.008Zm0 3.75h.008v.008H4.5v-.008Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.75 3.75h.008v.008h-.008V3.75Zm0 3.75h.008v.008h-.008V7.5Zm0 3.75h.008v.008h-.008v-.008Zm0 3.75h.008v.008h-.008v-.008Zm0 3.75h.008v.008h-.008v-.008Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M16.5 3.75h.008v.008h-.008V3.75Zm0 3.75h.008v.008h-.008V7.5Zm0 3.75h.008v.008h-.008v-.008Zm0 3.75h.008v.008h-.008v-.008Zm0 3.75h.008v.008h-.008v-.008Z" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const RESEARCH_MANAGER_ICON = `<svg fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M6.75 3.75v16.5M17.25 3.75v16.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3 12h18" stroke-linecap="round" stroke-linejoin="round"></path><path d="M7.5 7.5h4.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 16.5h4.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
export const DEVICE_PHONE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18h3" /></svg>`;
export const DEVICE_DESKTOP_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25A2.25 2.25 0 015.25 3h13.5A2.25 2.25 0 0121 5.25z" /></svg>`;
export const RADIOCITY_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-2.25a2.25 2.25 0 012.25-2.25h3a2.25 2.25 0 012.25 2.25V21m-6-13.5V6.75a2.25 2.25 0 012.25-2.25h3a2.25 2.25 0 012.25 2.25v.75" /></svg>`;
export const STORE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.658-.463 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>`;
export const PUBLICATIONS_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5M6 7.5h3v3H6v-3z" /></svg>`;
export const ABOUT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" /></svg>`;
export const CONTACT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>`;
export const CREDIT_CARD_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h6m3-3.75l3 3m0 0l3-3m-3 3V15m-3 6H6a2.25 2.25 0 01-2.25-2.25V7.5A2.25 2.25 0 016 5.25h12A2.25 2.25 0 0120.25 7.5v8.25a2.25 2.25 0 01-2.25 2.25H15M12 15h3v3h-3v-3z" /></svg>`;
export const API_KEY_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" /></svg>`;
export const PALETTE_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.098 19.902a3.75 3.75 0 005.304 0l6.401-6.402a3.75 3.75 0 00-.625-6.25A3.75 3.75 0 006.75 8.25l-2.652 2.652c-.317.317-.475.744-.475 1.175v3.328c0 .43.158.858.475 1.175z" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 12a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" /><path stroke-linecap="round" stroke-linejoin="round" d="M12.75 15.75l-3.75-3.75M16.5 13.5l-3.75-3.75" /></svg>`;
export const TROPHY_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 18.75h-9a9 9 0 119 0z" /><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v3m-3-3v3m6-3v3M12 3.75a3 3 0 00-3 3v3h6v-3a3 3 0 00-3-3z" /></svg>`;
export const FIRST_STEP_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M5.636 5.636a9 9 0 1012.728 0M12 3v9" /></svg>`;
export const WRITER_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487z" /><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 7.125L16.863 4.487" /></svg>`;
export const GENERATOR_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.5 21.75l-.398-1.188a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.188-.398a2.25 2.25 0 001.423-1.423L16.5 15.75l.398 1.188a2.25 2.25 0 001.423 1.423L19.5 18.75l-1.188.398a2.25 2.25 0 00-1.423 1.423z" /></svg>`;
export const SETTINGS_ICON = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-1.007 1.11-1.226.55-.22 1.156-.22 1.706 0 .55.22 1.02.684 1.11 1.226M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`;
export const STATS_ICON_2 = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;

// --- NAVIGATION ---
export const HEADER_NAV_ITEMS: NavItemType[] = [
    { id: 'dashboard', label: 'داشبورد', page: 'dashboard' },
    { id: 'radiocity', label: 'رادیوسیتی', page: 'radiocity' },
    {
      id: 'tools',
      label: 'ابزارها',
      icon: <Icon svg={CHEVRON_DOWN_ICON} className="w-4 h-4" />,
      children: [
        { id: 'image_generation', label: 'تولید تصویر', page: 'image_generation', icon: <Icon svg={IMAGE_ICON} /> },
        { id: 'video_generation', label: 'تولید ویدیو', page: 'video_generation', icon: <Icon svg={VIDEO_ICON} /> },
        { id: 'writing_center', label: 'مرکز نگارش', page: 'writing_center', icon: <Icon svg={WRITING_CENTER_ICON} /> },
        { id: 'translator_pro', label: 'مترجم تخصصی', page: 'translator_pro', icon: <Icon svg={TRANSLATOR_PRO_ICON} /> },
      ],
    },
    {
      id: 'resources',
      label: 'منابع',
      icon: <Icon svg={CHEVRON_DOWN_ICON} className="w-4 h-4" />,
      children: [
        { id: 'store', label: 'فروشگاه', page: 'store', icon: <Icon svg={STORE_ICON} /> },
        { id: 'publications', label: 'انتشارات', page: 'publications', icon: <Icon svg={PUBLICATIONS_ICON} /> },
        { id: 'academy', label: 'آکادمی', page: 'academy', icon: <Icon svg={ACADEMY_ICON} /> },
      ],
    },
     {
      id: 'about_us',
      label: 'درباره ما',
      icon: <Icon svg={CHEVRON_DOWN_ICON} className="w-4 h-4" />,
      children: [
        { id: 'about', label: 'درباره پلتفرم', page: 'about', icon: <Icon svg={ABOUT_ICON} /> },
        { id: 'contact', label: 'تماس با ما', page: 'contact', icon: <Icon svg={CONTACT_ICON} /> },
      ],
    },
];

export const RIGHT_SIDEBAR_NAV: NavItemType[] = [
    { id: 'main-title', label: 'اصلی', isSectionTitle: true },
    { id: 'dashboard', label: 'داشبورد', icon: <Icon svg={HOME_ICON} />, page: 'dashboard' },

    { id: 'gen-tools-title', label: 'ابزارهای تولید محتوا', isSectionTitle: true },
    { id: 'image_generation', label: 'تولید تصویر', icon: <Icon svg={IMAGE_ICON} />, page: 'image_generation' },
    { id: 'video_generation', label: 'تولید ویدیو', icon: <Icon svg={VIDEO_ICON} />, page: 'video_generation' },

    { id: 'research-tools-title', label: 'ابزارهای پژوهشی', isSectionTitle: true },
    { id: 'writing_center', label: 'مرکز نگارش', icon: <Icon svg={WRITING_CENTER_ICON} />, page: 'writing_center' },
    { id: 'translator_pro', label: 'مترجم تخصصی', icon: <Icon svg={TRANSLATOR_PRO_ICON} />, page: 'translator_pro' },
    { id: 'terminology_book', label: 'واژه‌نامه تخصصی', icon: <Icon svg={TERMINOLOGY_BOOK_ICON} />, page: 'terminology_book' },
    { id: 'plagiarism_checker', label: 'تشخیص سرقت', icon: <Icon svg={PLAGIARISM_CHECKER_ICON} />, page: 'plagiarism_checker' },
    { id: 'research_toolkit', label: 'جعبه ابزار پژوهش', icon: <Icon svg={RESEARCH_TOOLKIT_ICON} />, page: 'research_toolkit' },
    { id: 'data_lab', label: 'آزمایشگاه داده', icon: <Icon svg={DATA_LAB_ICON} />, page: 'data_lab' },
    { id: 'digital_library', label: 'کتابخانه دیجیتال', icon: <Icon svg={DIGITAL_LIBRARY_ICON} />, page: 'digital_library' },
    { id: 'surveys', label: 'نظرسنجی‌ها', icon: <Icon svg={SURVEYS_ICON} />, page: 'surveys' },
  
    { id: 'platform-title', label: 'پلتفرم', isSectionTitle: true },
    { id: 'radiocity', label: 'رادیوسیتی', icon: <Icon svg={RADIOCITY_ICON} />, page: 'radiocity' },
    { id: 'ai_center', label: 'مرکز هوش مصنوعی', icon: <Icon svg={AI_CENTER_ICON} />, page: 'ai_center' },
    { id: 'academy', label: 'آکادمی', icon: <Icon svg={ACADEMY_ICON} />, page: 'academy' },
    { id: 'wallet', label: 'کیف پول', icon: <Icon svg={WALLET_ICON} />, page: 'wallet' },

    { id: 'account-title', label: 'حساب کاربری', isSectionTitle: true },
    { id: 'profile', label: 'پروفایل', icon: <Icon svg={USER_ICON} />, page: 'profile' },
    { id: 'settings', label: 'تنظیمات', icon: <Icon svg={SETTINGS_ICON} />, page: 'settings' },
    { id: 'persona_chat', label: 'چت با شخصیت‌ها', icon: <Icon svg={PERSONA_CHAT_ICON} />, page: 'persona_chat' }
];

// --- MOCK DATA ---

export const STATS_CARDS_DATA: StatCardType[] = [
    { id: 'projects', title: 'کل پروژه‌ها', value: '3', change: '۱۵.۸% این هفته', changeType: 'increase', icon: <Icon svg={BOOK_ICON} />, color: "purple" },
    { id: 'words', title: 'کل کلمات', value: '120,150', change: '۴۲.۳% این ماه', changeType: 'increase', icon: <Icon svg={WORD_COUNT_ICON} />, color: "green" },
    { id: 'translations', title: 'ترجمه‌ها', value: '16', change: 'اکنون فعال', changeType: 'increase', icon: <Icon svg={TRANSLATE_ICON} />, color: "blue" },
    { id: 'collaborations', title: 'همکاری‌ها', value: '12', change: '۳ جدید این هفته', changeType: 'increase', icon: <Icon svg={COLLABORATION_ICON} />, color: "orange" },
];

export const QUICK_ACTIONS_DATA: QuickActionCardType[] = [
    { id: 'writing-center', title: 'مرکز نگارش', description: 'پردازش ساختار IMRAD', icon: <Icon svg={WRITING_CENTER_ICON} className="w-8 h-8"/>, color: 'purple', page: 'writing_center' },
    { id: 'translator', title: 'مترجم تخصصی', description: 'ترجمه دقیق و علمی', icon: <Icon svg={TRANSLATOR_PRO_ICON} className="w-8 h-8"/>, color: 'blue', page: 'translator_pro' },
    { id: 'plagiarism', title: 'تشخیص سرقت', description: 'بررسی اصالت متن', icon: <Icon svg={PLAGIARISM_CHECKER_ICON} className="w-8 h-8"/>, color: 'red', page: 'plagiarism_checker' },
    { id: 'vocab', title: 'واژه‌نامه', description: 'بانک ترمینولوژی', icon: <Icon svg={TERMINOLOGY_BOOK_ICON} className="w-8 h-8"/>, color: 'green', page: 'terminology_book' },
];

export const ACTIVE_TASKS_DATA: ActiveTaskType[] = [
    { id: 'task1', title: 'تاثیر فضاهای سبز شهری بر کیفیت زندگی', project: 'پروژه اول', progress: 65 },
    { id: 'task2', title: 'ترجمه مقاله ISI', project: 'پروژه دوم', progress: 30 },
];

export const RECENT_ACTIVITY_DATA: RecentActivityType[] = [
    { id: 'activity1', title: 'پروفایل شما آپدیت شد', date: '۱ ساعت پیش', icon: <Icon svg={USER_ICON} className="w-6 h-6 text-blue-400"/>, description: "بیوگرافی شما با موفقیت ویرایش شد.", page: 'settings' },
    { id: 'activity2', title: 'تصویر جدید ساخته شد', date: '۳ ساعت پیش', icon: <Icon svg={IMAGE_ICON} className="w-6 h-6 text-green-400"/>, description: "یک تصویر سینمایی از یک شهر آینده‌نگر.", page: 'image_generation' },
    { id: 'activity3', title: 'وظیفه جدید اضافه شد', date: 'دیروز', icon: <Icon svg={ACTIVE_TASK_ICON} className="w-6 h-6 text-yellow-400"/>, description: "پروژه جدیدی برای همکاری آغاز شد.", page: 'dashboard' },
    { id: 'activity4', title: 'کیف پول شارژ شد', date: '۲ روز پیش', icon: <Icon svg={WALLET_ICON} className="w-6 h-6 text-purple-400"/>, description: "اعتبار کیف پول شما افزایش یافت.", page: 'wallet' },
];

export const WEEKLY_PROGRESS_DATA: ChartDataType[] = [
    { label: 'شنبه', value: 30 },
    { label: '۱شنبه', value: 50 },
    { label: '۲شنبه', value: 80 },
    { label: '۳شنبه', value: 40 },
    { label: '۴شنبه', value: 65 },
    { label: '۵شنبه', value: 55 },
    { label: 'جمعه', value: 90 },
];

export const ACADEMY_COURSES_DATA: CourseType[] = [
    { id: 'c1', title: 'مبانی طراحی شهری پایدار', instructor: 'دکتر علیرضا محمدی', duration: '۶ ساعت', imageUrl: 'https://images.unsplash.com/photo-1549492423-4002122616fb?q=80&w=800&auto=format&fit=crop', tag: 'طراحی شهری' },
    { id: 'c2', title: 'تحلیل داده‌های مکانی با GIS', instructor: 'مهندس سارا رضایی', duration: '۸ ساعت', imageUrl: 'https://images.unsplash.com/photo-1572044162444-38f88e1479e3?q=80&w=800&auto=format&fit=crop', tag: 'فناوری' },
    { id: 'c3', title: 'جامعه‌شناسی فضای شهری', instructor: 'دکتر نرگس حسینی', duration: '۵ ساعت', imageUrl: 'https://images.unsplash.com/photo-1517581177682-a085bb7ffb12?q=80&w=800&auto=format&fit=crop', tag: 'جامعه‌شناسی' },
    { id: 'c4', title: 'کاربرد هوش مصنوعی در شهرسازی', instructor: 'پروفسور کاوه احمدی', duration: '۱۰ ساعت', imageUrl: 'https://images.unsplash.com/photo-1677756119517-756a188d2d94?q=80&w=800&auto=format&fit=crop', tag: 'AI' },
];

export const WALLET_SUMMARY_DATA: WalletSummaryType = {
    balance: 250000,
    currency: 'تومان',
    spentThisMonth: 75000,
};

export const WALLET_TRANSACTIONS_DATA: TransactionType[] = [
    { id: 't1', description: 'شارژ حساب', date: '۱۴۰۳/۰۴/۰۱', amount: 100000, type: 'credit' },
    { id: 't2', description: 'خرید دوره آموزشی', date: '۱۴۰۳/۰۴/۰۳', amount: 45000, type: 'debit' },
    { id: 't3', description: 'استفاده از سرویس تولید تصویر', date: '۱۴۰۳/۰۴/۰۵', amount: 12000, type: 'debit' },
    { id: 't4', description: 'بازگشت وجه', date: '۱۴۰۳/۰۴/۰۸', amount: 5000, type: 'credit' },
];

export const PERSONA_CHAT_DATA: PersonaType[] = [
    { id: 'p1', name: 'جین جیکوبز', title: 'نظریه‌پرداز شهری', avatarUrl: 'https://api.dicebear.com/7.x/lorelei/svg?seed=JaneJacobs', expertise: 'فضاهای عمومی، اجتماع‌محوری', greeting: 'سلام! چگونه می‌توانیم شهرهایمان را برای مردم زنده‌تر کنیم؟' },
    { id: 'p2', name: 'کوین لینچ', title: 'پژوهشگر تصویر ذهنی شهر', avatarUrl: 'https://api.dicebear.com/7.x/lorelei/svg?seed=KevinLynch', expertise: 'خوانایی، سیمای شهر', greeting: 'سلام، آماده‌ام تا در مورد تصویر ذهنی شهر و عناصر سازنده‌اش با شما صحبت کنم.' },
    { id: 'p3', name: 'یان گیل', title: 'معمار و طراح شهری', avatarUrl: 'https://api.dicebear.com/7.x/lorelei/svg?seed=JanGehl', expertise: 'حیات بین ساختمان‌ها، مقیاس انسانی', greeting: 'درود! بیایید در مورد چگونگی طراحی شهرهایی برای انسان‌ها گفتگو کنیم.' },
];

const achievementsData: Omit<AchievementType, 'unlocked'>[] = [
    { id: 'ach1', name: 'اولین گام', description: 'اولین پروژه خود را ایجاد کردید.', icon: FIRST_STEP_ICON },
    { id: 'ach2', name: 'استاد قلم', description: 'بیش از ۱۰,۰۰۰ کلمه نوشتید.', icon: WRITER_ICON },
    { id: 'ach3', name: 'خالق تصاویر', description: 'بیش از ۱۰ تصویر تولید کردید.', icon: GENERATOR_ICON },
    { id: 'ach4', name: 'همکار نمونه', description: 'در یک پروژه همکاری کردید.', icon: COLLABORATION_ICON },
    { id: 'ach5', name: 'پژوهشگر برتر', description: 'به سطح ۱۰ رسیدید.', icon: TROPHY_ICON },
    { id: 'ach6', name: 'شهرساز اجتماعی', description: 'با یک شخصیت گفتگو کردید.', icon: PERSONA_CHAT_ICON },
];

export const USER_PROFILE_DATA: UserProfileType = {
    name: 'کاربر حرفه‌ای',
    title: 'پژوهشگر مطالعات شهری',
    organization: 'دانشگاه شهرسازی',
    website: 'urbanist.dev',
    level: 12,
    points: 12580,
    avatarUrl: 'https://api.dicebear.com/7.x/lorelei/svg?seed=Urbanist',
    joinDate: 'اسفند ۱۴۰۲',
    bio: 'پژوهشگر مطالعات شهری با علاقه به تحلیل داده‌های مکانی و طراحی شهری پایدار. در حال کار بر روی پایان‌نامه دکتری با موضوع تاب‌آوری شهری در برابر تغییرات اقلیمی.',
    skills: ['طراحی شهری', 'GIS', 'تحلیل داده', 'پایداری', 'تاب‌آوری شهری', 'هوش مصنوعی'],
    achievements: achievementsData.map((ach, i) => ({ ...ach, unlocked: i < 4 })) // Mock unlocked status
};

export const MOCK_VIDEOS_DATA: VideoType[] = [
    { id: 'v1', thumbnailUrl: 'https://picsum.photos/seed/vid1/500/281', videoUrl: '#' },
    { id: 'v2', thumbnailUrl: 'https://picsum.photos/seed/vid2/500/281', videoUrl: '#' },
    { id: 'v3', thumbnailUrl: 'https://picsum.photos/seed/vid3/500/281', videoUrl: '#' },
];
