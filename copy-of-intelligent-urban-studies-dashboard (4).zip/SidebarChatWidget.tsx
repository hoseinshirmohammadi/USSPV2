
import React, { useState, useRef, useEffect } from 'react';
import { Card } from '../atoms/Card';
import { Icon } from '../atoms/Icon';
import { AI_ASSISTANT_ICON, SEND_ICON, MINIMIZE_ICON, MAXIMIZE_ICON } from '../../constants';
import { MessageType } from '../../types';

export const SidebarChatWidget: React.FC = () => {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [messages, setMessages] = useState<MessageType[]>([
        { id: '1', text: 'سلام! چطور میتونم به شما کمک کنم؟', sender: 'persona' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }

    useEffect(scrollToBottom, [messages, isCollapsed]);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
        }
    }, [inputValue]);
    
    const handleSend = () => {
        if (inputValue.trim()) {
            const newUserMessage: MessageType = { id: `msg-${Date.now()}`, text: inputValue.trim(), sender: 'user' };
            setMessages(prev => [...prev, newUserMessage]);
            setInputValue('');

            setTimeout(() => {
                const aiResponse: MessageType = { id: `msg-${Date.now() + 1}`, text: `پاسخ شبیه‌سازی شده...`, sender: 'persona' };
                setMessages(prev => [...prev, aiResponse]);
            }, 1000);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <Card className="flex flex-col flex-grow min-h-0" padding="p-0">
            <div 
                className="flex items-center justify-between cursor-pointer p-3"
                onClick={() => setIsCollapsed(prev => !prev)}
            >
                <div className="flex items-center">
                    <Icon svg={AI_ASSISTANT_ICON} className="w-5 h-5 text-primary me-2" />
                    <h4 className="font-bold text-white text-sm">دستیار هوشمند</h4>
                </div>
                <button className="text-gray-400 hover:text-white">
                    <Icon svg={isCollapsed ? MAXIMIZE_ICON : MINIMIZE_ICON} className="w-4 h-4" />
                </button>
            </div>
            {!isCollapsed && (
                <div className="flex flex-col flex-grow min-h-0">
                    <div className="flex-grow overflow-y-auto p-3 space-y-3 chat-message-list">
                        {messages.map((message) => (
                            <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`chat-bubble text-xs ${message.sender === 'user' ? 'chat-bubble-user' : 'chat-bubble-persona'}`}>
                                    {message.text}
                                </div>
                            </div>
                        ))}
                         <div ref={messagesEndRef} />
                    </div>
                    <div className="p-2 border-t border-white/10">
                        <div className="relative flex items-end">
                            <textarea 
                                ref={textareaRef}
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="پیام شما..."
                                className="w-full text-sm bg-black/20 border-none rounded-lg p-2 pe-10 autoresize-textarea max-h-24 focus:ring-0"
                                rows={1}
                            />
                            <button onClick={handleSend} className="absolute bottom-2 end-2 text-primary hover:text-white transition-colors">
                                <Icon svg={SEND_ICON} className="w-5 h-5"/>
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </Card>
    );
};