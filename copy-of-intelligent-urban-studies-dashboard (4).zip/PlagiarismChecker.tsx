import React, { useState, useLayoutEffect } from 'react';
import { Card } from '../components/atoms/Card';
import { Button } from '../components/atoms/Button';
import { Icon } from '../components/atoms/Icon';
import { useLayout } from '../hooks/useLayout';
import { StaggeredGrid } from '../components/atoms/StaggeredGrid';
import { PLAGIARISM_CHECKER_ICON } from '../constants';

const PageHeader = ({ title, subtitle }: { title: string; subtitle: string }) => (
    <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">{title}</h1>
        <p className="text-gray-400 mt-2">{subtitle}</p>
    </div>
);

const DonutChart: React.FC<{ percentage: number }> = ({ percentage }) => {
    const strokeWidth = 10;
    const radius = 60;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (percentage / 100) * circumference;

    return (
        <div className="relative w-40 h-40">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 140 140">
                <circle className="text-white/10" stroke="currentColor" strokeWidth={strokeWidth} fill="transparent" r={radius} cx="70" cy="70" />
                <circle className="text-red-500" stroke="currentColor" strokeWidth={strokeWidth} fill="transparent" r={radius} cx="70" cy="70" strokeLinecap="round" style={{ strokeDasharray: circumference, strokeDashoffset, transition: 'stroke-dashoffset 0.5s ease-out' }} />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-white">{percentage}%</span>
                <span className="text-xs text-gray-400">شباهت</span>
            </div>
        </div>
    );
};

const PlagiarismChecker: React.FC = () => {
    const { setSidebarContent } = useLayout();
    const [text, setText] = useState('');
    const [result, setResult] = useState<{ score: number; sources: any[] } | null>(null);
    const [loading, setLoading] = useState(false);

    const handleCheck = () => {
        if (!text) return;
        setLoading(true);
        setResult(null);
        setTimeout(() => {
            setResult({
                score: 23,
                sources: [
                    { title: 'K. Lynch, The Image of the City, 1960', similarity: '8%' },
                    { title: 'J. Gehl, Life Between Buildings, 1971', similarity: '6%' },
                    { title: 'Wikipedia: Urban Planning', similarity: '5%' },
                ]
            });
            setLoading(false);
        }, 2500);
    };

    useLayoutEffect(() => {
        setSidebarContent(null);
    }, [setSidebarContent]);

    return (
        <div className="page-container">
            <StaggeredGrid>
                <PageHeader title="تشخیص سرقت علمی" subtitle="اصالت متون پژوهشی خود را با الگوریتم‌های پیشرفته بررسی کنید." />

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        <Card className="flex flex-col h-[60vh]">
                            <textarea
                                value={text}
                                onChange={(e) => setText(e.target.value)}
                                className="form-control flex-grow w-full bg-transparent border-none focus:ring-0 p-0"
                                placeholder="متن خود را برای بررسی اینجا وارد کنید یا فایل خود را آپلود نمایید..."
                            />
                             <div className="border-t border-white/10 p-4 flex justify-end items-center space-x-4 rtl:space-x-reverse">
                                <Button variant="secondary">آپلود فایل</Button>
                                <Button onClick={handleCheck} disabled={loading || !text}>
                                    {loading ? 'در حال بررسی...' : 'بررسی کن'}
                                </Button>
                            </div>
                        </Card>
                    </div>
                    <div className="lg:col-span-1">
                        <Card className="h-full">
                            <h3 className="font-bold text-lg text-white mb-4 text-center">گزارش مشابهت</h3>
                            {loading ? (
                                <div className="flex items-center justify-center h-full">
                                    <Icon svg={PLAGIARISM_CHECKER_ICON} className="w-12 h-12 text-primary animate-spin" />
                                </div>
                            ) : result ? (
                                <div className="flex flex-col items-center space-y-6">
                                    <DonutChart percentage={result.score} />
                                    <div className="w-full">
                                        <h4 className="font-semibold text-white mb-3">منابع مشابه یافت شده:</h4>
                                        <ul className="space-y-2">
                                            {result.sources.map((source, i) => (
                                                <li key={i} className="text-sm p-2 bg-white/5 rounded-md flex justify-between">
                                                    <span className="text-gray-300 truncate w-3/4">{source.title}</span>
                                                    <span className="text-red-400 font-semibold">{source.similarity}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
                                    <Icon svg={PLAGIARISM_CHECKER_ICON} className="w-16 h-16 mx-auto mb-4" />
                                    <p>نتایج بررسی در اینجا نمایش داده می‌شود.</p>
                                </div>
                            )}
                        </Card>
                    </div>
                </div>
            </StaggeredGrid>
        </div>
    );
};

export default PlagiarismChecker;
