import React from 'react';
import { NavItemType } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import { Tooltip } from '../atoms/Tooltip';
import { motion } from 'framer-motion';

interface NavItemProps {
  item: NavItemType;
  isCollapsed: boolean;
}

export const NavItem: React.FC<NavItemProps> = ({ item, isCollapsed }) => {
  const { isRtl, currentPage, setCurrentPage } = useAppContext();

  if (item.isSectionTitle) {
    return (
      <h3 className={`px-4 pt-6 pb-2 text-xs font-bold text-gray-400 uppercase tracking-wider transition-opacity duration-200 ${isCollapsed ? 'opacity-0 text-center' : 'opacity-100'}`}>
        {isCollapsed ? '·' : item.label}
      </h3>
    );
  }
  
  const isActive = currentPage === item.page;

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (item.page) {
      setCurrentPage(item.page);
    }
  };
  
  const navItemContent = (
    <div className={`relative flex items-center justify-center w-full h-12 text-sm font-medium rounded-lg transition-colors duration-200 group cursor-pointer my-1 ${isActive ? 'bg-white/10 text-white' : 'text-gray-400 hover:bg-white/5 focus-visible:bg-white/5 hover:text-white focus-visible:text-white'}`}>
        {isActive && (
            <motion.div 
                layoutId="active-nav-glow"
                className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent to-primary/20 border-r-2 border-primary"
                style={isRtl ? { transform: 'scaleX(-1)'} : {}}
                transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            />
        )}
        <div className={`relative flex items-center w-full transition-all duration-300 ${isRtl ? 'flex-row-reverse justify-start' : 'flex-row'} ${isCollapsed ? 'justify-center' : 'px-4'}`}>
            <motion.div 
                className={`flex-shrink-0 transition-colors duration-200 ${isActive ? 'text-primary' : 'text-gray-500 group-hover:text-primary group-focus-visible:text-primary'}`}
                whileHover={{ scale: 1.2, rotate: [0, 10, -10, 0] }}
                transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                >
                {item.icon}
            </motion.div>
            {!isCollapsed && (
                <span className={`flex-grow text-start transition-opacity duration-200 ${isRtl ? 'me-3 text-right' : 'ms-3'}`}>{item.label}</span>
            )}
        </div>
    </div>
  );


  if (isCollapsed) {
    return (
      <Tooltip text={item.label} position={isRtl ? 'left' : 'right'}>
        <a href="#" onClick={handleClick} className="w-12 mx-auto block">
            {navItemContent}
        </a>
      </Tooltip>
    );
  }

  return (
    <a href="#" onClick={handleClick}>
        {navItemContent}
    </a>
  );
};
