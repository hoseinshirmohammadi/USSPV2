
import React from 'react';
import { RecentActivityType } from '../../types';

interface ActivityItemProps {
  activity: RecentActivityType;
}

export const ActivityItem: React.FC<ActivityItemProps> = ({ activity }) => {
  return (
    <div className="flex items-center space-x-4 rtl:space-x-reverse py-3">
        <div className="p-2 bg-gray-700/50 rounded-lg">
            {activity.icon}
        </div>
        <div className="flex-grow">
            <p className="font-medium text-white">{activity.title}</p>
            <p className="text-xs text-gray-400">{activity.date}</p>
        </div>
    </div>
  );
};