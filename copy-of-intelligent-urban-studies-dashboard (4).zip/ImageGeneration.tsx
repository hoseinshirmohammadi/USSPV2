import React, { useState, useLayoutEffect, useCallback } from 'react';
import { Card } from '../components/atoms/Card';
import { Button } from '../components/atoms/Button';
import { IMAGE_ICON } from '../constants';
import { useLayout } from '../hooks/useLayout';
import { Icon } from '../components/atoms/Icon';

const PageHeader = ({ title, subtitle }: { title: string; subtitle: string }) => (
  <div className="mb-8">
    <h1 className="text-3xl font-bold text-white">{title}</h1>
    <p className="text-gray-400 mt-2">{subtitle}</p>
  </div>
);

const ImageGenerationSidebar: React.FC<{ onGenerate: () => void }> = ({ onGenerate }) => {
    return (
      <div className="space-y-6">
        <div>
            <label htmlFor="prompt" className="form-label">پرامپت (دستور)</label>
            <textarea id="prompt" rows={5} className="form-control" placeholder="مثال: یک شهر آینده‌نگر در زیر اقیانوس..."></textarea>
        </div>
        <div>
            <label htmlFor="neg-prompt" className="form-label">پرامپت منفی</label>
            <textarea id="neg-prompt" rows={3} className="form-control" placeholder="مثال: تار، کیفیت پایین، متن..."></textarea>
        </div>
        <div>
            <label className="form-label">نسبت تصویر</label>
            <div className="grid grid-cols-3 gap-2">
                {['1:1', '16:9', '9:16', '4:3', '3:4'].map(ratio => (
                    <button key={ratio} className="px-2 py-1.5 text-xs bg-white/5 rounded-md hover:bg-primary hover:text-white transition-colors focus-visible:bg-primary focus-visible:text-white focus:outline-none">{ratio}</button>
                ))}
            </div>
        </div>
        <div>
            <label className="form-label">سبک</label>
            <select className="form-control">
                <option>سینمایی</option>
                <option>انیمه</option>
                <option>فتورئالیسم</option>
                <option>هنر دیجیتال</option>
            </select>
        </div>
        <Button onClick={onGenerate} icon={IMAGE_ICON} className="w-full">
          تولید تصویر
        </Button>
      </div>
    );
};

const ImageCard: React.FC<{ src: string, isLoading: boolean }> = ({ src, isLoading }) => (
    <Card className={`aspect-square relative overflow-hidden group ${isLoading ? 'animate-pulse bg-white/5' : 'glow-border cursor-pointer'}`}>
        {!isLoading && <img src={src} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"/>}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
            <Button size="sm" variant="secondary">دانلود</Button>
            <Button size="sm" variant="secondary">حذف</Button>
        </div>
    </Card>
);

const ImageGeneration: React.FC = () => {
  const { setSidebarContent } = useLayout();
  const [images, setImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = useCallback(() => {
      setIsLoading(true);
      // Simulate API call
      setTimeout(() => {
          const newImage = `https://picsum.photos/seed/${Math.random()}/500/500`;
          setImages(prev => [newImage, ...prev]);
          setIsLoading(false);
      }, 2000);
  }, []);

  useLayoutEffect(() => {
    setSidebarContent(<ImageGenerationSidebar onGenerate={handleGenerate} />);
    return () => setSidebarContent(null);
  }, [setSidebarContent, handleGenerate]);


  return (
    <div className="page-container">
      <PageHeader title="تولید تصویر با هوش مصنوعی" subtitle="ایده‌های خود را به تصاویر خارق‌العاده تبدیل کنید." />
      
      <h3 className="font-bold text-white mb-4">گالری شما</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {isLoading && <ImageCard src="" isLoading={true} />}
        {images.map((img, index) => <ImageCard key={index} src={img} isLoading={false} />)}
      </div>

       {images.length === 0 && !isLoading && (
        <Card className="text-center py-16 border-dashed border-white/20">
            <Icon svg={IMAGE_ICON} className="w-12 h-12 mx-auto text-gray-500 mb-4"/>
            <h3 className="text-white font-bold">گالری شما خالی است</h3>
            <p className="text-gray-400 text-sm mt-2">از پنل کناری برای ساخت اولین تصویر خود استفاده کنید.</p>
        </Card>
      )}

    </div>
  );
};
export default ImageGeneration;
