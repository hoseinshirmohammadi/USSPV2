
import React from 'react';
import { Card } from '../atoms/Card';
import { Icon } from '../atoms/Icon';
import { StatCard } from '../molecules/StatCard';
import { QuickActionCard } from '../molecules/QuickActionCard';
import { ActivityItem } from '../molecules/ActivityItem';
import { DataChart } from './DataChart';
import {
  STATS_CARDS_DATA,
  QUICK_ACCESS_CARDS_DATA,
  QUICK_ACTIONS_DATA,
  ACTIVE_TASKS_DATA,
  RECENT_ACTIVITY_DATA,
  WEEKLY_PROGRESS_DATA,
  FILTER_ICON,
  REFRESH_ICON,
  ACTIVITY_PULSE_ICON,
  ACTIVE_TASK_ICON,
  QUICK_ACCESS_SPEED_ICON,
  CHART_BAR_ICON
} from '../../constants';
import { ActiveTaskType, QuickActionCardType, RecentActivityType, StatCardType } from '../../types';

interface DashboardGridProps {
  isRtl: boolean;
}

const WelcomeHeader: React.FC = () => (
  <div className="mb-8 animate-fade-in-up">
    <h1 className="text-4xl font-bold text-white">به پلتفرم هوشمند خوش آمدید,</h1>
    <h2 className="text-4xl font-bold text-gradient-primary">!user</h2>
    <p className="text-gray-400 mt-2">یک نمای کلی از فعالیت‌ها و پیشرفت‌های شما</p>
  </div>
);

const SectionHeader: React.FC<{ title: string; icon: React.ReactNode }> = ({ title, icon }) => (
  <div className="flex items-center mb-4">
    <div className="p-1.5 bg-primary/10 text-primary rounded-md me-3">{icon}</div>
    <h3 className="font-bold text-white text-lg">{title}</h3>
  </div>
);

const DashboardGrid: React.FC<DashboardGridProps> = ({ isRtl }) => {
  return (
    <div className="p-4 sm:p-8">
        <div className="flex justify-between items-start mb-6 flex-wrap">
            <WelcomeHeader />
             <div className="flex space-x-2 rtl:space-x-reverse mt-4 sm:mt-0">
                <button className="flex items-center space-x-2 rtl:space-x-reverse px-4 py-2 text-sm bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
                    <Icon svg={FILTER_ICON} className="w-4 h-4" />
                    <span>فیلتر</span>
                </button>
                 <button className="flex items-center space-x-2 rtl:space-x-reverse px-4 py-2 text-sm bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
                    <Icon svg={REFRESH_ICON} className="w-4 h-4" />
                    <span>به‌روزرسانی</span>
                </button>
            </div>
        </div>

      {/* Quick Access */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-8">
        {QUICK_ACCESS_CARDS_DATA.map((action: QuickActionCardType) => (
          <QuickActionCard key={action.id} action={action} />
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {STATS_CARDS_DATA.map((stat: StatCardType) => (
          <StatCard key={stat.id} stat={stat} />
        ))}
      </div>
      
       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Weekly Progress Chart */}
        <div className="lg:col-span-2">
           <DataChart title="پیشرفت هفتگی" icon={<Icon svg={CHART_BAR_ICON} className="w-5 h-5"/>} data={WEEKLY_PROGRESS_DATA} />
        </div>
        
        {/* Quick Actions */}
        <div className="lg:col-span-1">
             <SectionHeader title="اقدامات سریع" icon={<Icon svg={QUICK_ACCESS_SPEED_ICON} className="w-5 h-5" />} />
             <div className="grid grid-cols-2 gap-4">
                {QUICK_ACTIONS_DATA.slice(0, 4).map((action: QuickActionCardType) => (
                    <QuickActionCard key={action.id} action={action} />
                ))}
            </div>
        </div>
      </div>


      {/* Active Tasks & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1" padding="p-4">
           <SectionHeader title="وظایف فعال" icon={<Icon svg={ACTIVE_TASK_ICON} className="w-5 h-5" />} />
            <div className="space-y-4">
                {ACTIVE_TASKS_DATA.map((task: ActiveTaskType) => (
                    <Card key={task.id} className="bg-primary/10" padding="p-4">
                        <p className="text-sm font-medium text-white">{task.title}</p>
                        <p className="text-xs text-primary mb-2">{task.project}</p>
                        <div className="w-full bg-gray-700/50 rounded-full h-2">
                            <div className="bg-primary h-2 rounded-full" style={{ width: `${task.progress}%` }}></div>
                        </div>
                         <div className="flex justify-between text-xs mt-1">
                            <span>پیشرفت</span>
                            <span>{task.progress}%</span>
                        </div>
                    </Card>
                ))}
            </div>
        </Card>

        <Card className="lg:col-span-2" padding="p-4">
            <SectionHeader title="فعالیت‌های اخیر" icon={<Icon svg={ACTIVITY_PULSE_ICON} className="w-5 h-5"/>} />
             <div className="divide-y divide-white/10">
                {RECENT_ACTIVITY_DATA.map((activity: RecentActivityType) => (
                    <ActivityItem key={activity.id} activity={activity} />
                ))}
            </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardGrid;
