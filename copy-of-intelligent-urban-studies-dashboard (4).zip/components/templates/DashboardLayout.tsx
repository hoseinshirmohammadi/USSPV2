
import React from 'react';
import Header from '../organisms/Header';
import { RightSidebar } from '../organisms/RightSidebar';
import { LeftSidebar } from '../organisms/LeftSidebar';
import { useAppContext } from '../../hooks/useAppContext';
import { LayoutProvider } from '../../context/LayoutContext';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { isRtl, isRightSidebarCollapsed } = useAppContext();
  
  const getMarginClasses = () => {
    // right sidebar: collapsed w-20 (5rem), expanded w-64 (16rem)
    // left sidebar: w-72 (18rem)
    // margin on sidebars: m-2 (0.5rem each side) -> total width = w + 1rem
    // Correct margin values:
    // Right Collapsed: 5rem + 1rem = 6rem
    // Right Expanded: 16rem + 1rem = 17rem
    // Left: 18rem + 1rem = 19rem
    if (isRtl) {
      const rightMargin = isRightSidebarCollapsed ? 'lg:mr-[6rem]' : 'lg:mr-[17rem]';
      return `${rightMargin} lg:ml-[19rem]`;
    }
    // LTR
    const leftMargin = isRightSidebarCollapsed ? 'lg:ml-[6rem]' : 'lg:ml-[17rem]';
    return `${leftMargin} lg:mr-[19rem]`;
  };

  return (
    <LayoutProvider>
      <div className="min-h-screen">
        <Header />
        <RightSidebar />
        <LeftSidebar />
        
        <main className={`relative transition-all duration-300 ease-in-out pt-16 min-h-screen ${getMarginClasses()}`}>
            <div className="flex-grow min-w-0">
                {children}
            </div>
        </main>
      </div>
    </LayoutProvider>
  );
};

export default DashboardLayout;
