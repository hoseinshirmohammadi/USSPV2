import React from 'react';
import { Card } from '../atoms/Card';
import { Icon } from '../atoms/Icon';
import { ActivityItem } from '../molecules/ActivityItem';
import { RECENT_ACTIVITY_DATA, ACTIVITY_PULSE_ICON } from '../../constants';

export const RecentActivityWidget: React.FC = () => (
    <Card>
        <div className="flex items-center mb-4">
            <div className="p-1.5 bg-yellow-400/20 text-yellow-400 rounded-md me-3">
                <Icon svg={ACTIVITY_PULSE_ICON} className="w-5 h-5"/>
            </div>
            <h3 className="font-bold text-white text-lg">فعالیت‌های اخیر</h3>
        </div>
        <div className="divide-y divide-white/10 -mx-4">
            {RECENT_ACTIVITY_DATA.map((activity) => (
                <ActivityItem key={activity.id} activity={activity} />
            ))}
        </div>
    </Card>
);
