import React, { useLayoutEffect, useState } from 'react';
import { Card } from '../components/atoms/Card';
import { Button } from '../components/atoms/Button';
import { Icon } from '../components/atoms/Icon';
import { useLayout } from '../hooks/useLayout';
import { StaggeredGrid } from '../components/atoms/StaggeredGrid';
import { DATA_LAB_ICON, CHART_BAR_ICON } from '../constants';
import { DataChart } from '../components/organisms/DataChart';

const PageHeader = ({ title, subtitle }: { title: string; subtitle: string }) => (
    <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">{title}</h1>
        <p className="text-gray-400 mt-2">{subtitle}</p>
    </div>
);

const mockChartData = [
    { label: 'متغیر ۱', value: 30 },
    { label: 'متغیر ۲', value: 50 },
    { label: 'متغیر ۳', value: 80 },
    { label: 'متغیر ۴', value: 40 },
];

const StatDisplay: React.FC<{ label: string, value: string }> = ({ label, value }) => (
    <div className="bg-white/5 p-4 rounded-lg text-center">
        <p className="text-sm text-gray-400">{label}</p>
        <p className="text-2xl font-bold text-white mt-1">{value}</p>
    </div>
);

const DataLab: React.FC = () => {
    const { setSidebarContent } = useLayout();
    const [dataset, setDataset] = useState<string | null>(null);

    useLayoutEffect(() => {
        setSidebarContent(null);
    }, [setSidebarContent]);

    return (
        <div className="page-container">
            <StaggeredGrid>
                <PageHeader title="آزمایشگاه تحلیل داده" subtitle="داده‌های خود را بارگذاری کرده و تحلیل‌های آماری و بصری انجام دهید." />
                
                {!dataset ? (
                     <Card className="text-center py-24 border-dashed border-white/20">
                        <Icon svg={DATA_LAB_ICON} className="w-16 h-16 mx-auto text-gray-500 mb-4"/>
                        <h3 className="text-white font-bold text-xl">هنوز داده‌ای بارگذاری نشده است</h3>
                        <p className="text-gray-400 text-sm mt-2 mb-6">برای شروع تحلیل، فایل داده خود (CSV, Excel) را بارگذاری کنید.</p>
                        <Button onClick={() => setDataset('urban_data.csv')}>بارگذاری داده نمونه</Button>
                    </Card>
                ) : (
                    <div className="space-y-8">
                        <Card>
                            <h3 className="font-bold text-lg text-white mb-4">تحلیل توصیفی: {dataset}</h3>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                               <StatDisplay label="تعداد مشاهدات" value="1,450" />
                               <StatDisplay label="تعداد متغیرها" value="12" />
                               <StatDisplay label="مقادیر گمشده" value="3.4%" />
                               <StatDisplay label="نوع تحلیل پیشنهادی" value="ANOVA" />
                            </div>
                        </Card>
                        <DataChart title="بصری‌سازی داده" icon={<Icon svg={CHART_BAR_ICON} className="w-5 h-5"/>} data={mockChartData} />
                        <Card>
                             <h3 className="font-bold text-lg text-white mb-4">کدنویسی سفارشی (Python/R)</h3>
                             <div className="code-block">
                                <pre><code>{`import pandas as pd\n\ndf = pd.read_csv("urban_data.csv")\nprint(df.describe())`}</code></pre>
                             </div>
                        </Card>
                    </div>
                )}

            </StaggeredGrid>
        </div>
    );
};

export default DataLab;
