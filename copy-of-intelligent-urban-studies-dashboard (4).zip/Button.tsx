import React from 'react';
import { Icon } from './Icon';
import { motion, HTMLMotionProps } from 'framer-motion';
import { useAppContext } from '../../hooks/useAppContext';

interface ButtonProps extends HTMLMotionProps<'button'> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'gradient';
  size?: 'sm' | 'md' | 'lg';
  icon?: string;
  iconPosition?: 'left' | 'right';
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  className = '',
  ...props
}) => {
  const { isRtl } = useAppContext();

  const variantClasses = {
    primary: 'btn-primary',
    secondary: 'btn-secondary',
    gradient: 'btn-gradient',
  };

  const sizeClasses = {
    sm: 'text-xs px-3 py-1.5',
    md: 'text-sm px-5 py-2.5',
    lg: 'text-base px-7 py-3',
  };

  const iconSizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  const finalIconPosition = isRtl ? (iconPosition === 'left' ? 'right' : 'left') : iconPosition;

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 400, damping: 15 }}
      className={`btn ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {icon && finalIconPosition === 'left' && (
        <Icon svg={icon} className={`${iconSizeClasses[size]} me-2`} />
      )}
      <span>{children}</span>
      {icon && finalIconPosition === 'right' && (
        <Icon svg={icon} className={`${iconSizeClasses[size]} ms-2`} />
      )}
    </motion.button>
  );
};
