
import React from 'react';
import { StatCardType } from '../../types';
import { Card } from '../atoms/Card';

export const StatCard: React.FC<{ stat: StatCardType }> = ({ stat }) => {
  const changeColor = stat.changeType === 'increase' ? 'text-green-400' : 'text-red-400';

  return (
    <Card className={`relative overflow-hidden glow-border`}>
      <div className="flex flex-col h-full justify-between">
          <div className="flex justify-between items-start">
            <h3 className="font-bold text-white">{stat.title}</h3>
            <div className="p-2 bg-black/30 rounded-lg text-primary">{stat.icon}</div>
          </div>
          <div>
            <p className="text-3xl font-bold text-white mt-4">{stat.value}</p>
            <div className="flex items-center text-xs text-gray-400 mt-1">
              <span className={`me-2 ${changeColor}`}>{stat.change}</span>
            </div>
          </div>
      </div>
    </Card>
  );
};