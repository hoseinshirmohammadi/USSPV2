import React from 'react';
import { Icon } from './Icon';
import { motion, HTMLMotionProps } from 'framer-motion';

interface ButtonProps extends HTMLMotionProps<'button'> {
  children: React.ReactNode;
  variant?: 'glow-cta' | 'glass' | 'ghost' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
  icon?: string;
  iconPosition?: 'left' | 'right';
  isRtl?: boolean;
  className?: string;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'glow-cta',
  size = 'md',
  icon,
  iconPosition = 'left',
  isRtl = true,
  className = '',
  ...props
}) => {
  const baseClasses = 'flex items-center justify-center font-semibold rounded-full transition-all duration-300 focus:outline-none';

  const sizeClasses = {
    sm: 'px-4 py-2 text-xs',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-base',
  };

  const variantClasses = {
    'glow-cta': 'btn-glow-cta',
    glass: 'btn-glass',
    ghost: 'bg-transparent text-gray-300 hover:bg-white/10 hover:text-white',
    secondary: 'bg-white/10 text-white hover:bg-white/20',
  };

  const iconSizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  const finalIconPosition = isRtl ? (iconPosition === 'left' ? 'right' : 'left') : iconPosition;

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 400, damping: 15 }}
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {icon && finalIconPosition === 'left' && (
        <Icon svg={icon} className={`${iconSizeClasses[size]} ${isRtl ? 'ml-2' : 'mr-2'}`} />
      )}
      <span>{children}</span>
      {icon && finalIconPosition === 'right' && (
        <Icon svg={icon} className={`${iconSizeClasses[size]} ${isRtl ? 'mr-2' : 'ml-2'}`} />
      )}
    </motion.button>
  );
};
