
import React from 'react';
import { Card } from '../atoms/Card';
import { ChartDataType } from '../../types';
import { motion, Variants } from 'framer-motion';

interface DataChartProps {
  title: string;
  icon: React.ReactNode;
  data: ChartDataType[];
}

const SectionHeader: React.FC<{ title: string; icon: React.ReactNode }> = ({ title, icon }) => (
    <div className="flex items-center mb-6">
      <div className="p-1.5 bg-primary/10 text-primary rounded-md me-3">{icon}</div>
      <h3 className="font-bold text-white text-lg">{title}</h3>
    </div>
  );

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const barVariants: Variants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100
    }
  },
};

export const DataChart: React.FC<DataChartProps> = ({ title, icon, data }) => {
  const maxValue = Math.max(...data.map(item => item.value), 0) * 1.2;

  return (
    <Card className="h-full">
      <SectionHeader title={title} icon={icon} />
      <motion.div 
        className="relative flex justify-around items-end h-64 space-x-2 rtl:space-x-reverse px-2"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        whileInView="visible"
        viewport={{ once: true }}
      >
        {/* Grid Background */}
        <div className="absolute inset-0 top-0 bottom-8 grid grid-rows-4 -z-10">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="border-b border-white/5"></div>
          ))}
        </div>

        {data.map((item, index) => (
          <motion.div key={index} variants={barVariants} className="flex-1 h-full flex flex-col items-center justify-end group relative">
            <div className="absolute -top-10 opacity-0 group-hover:opacity-100 group-hover:-translate-y-2 transition-all duration-300 bg-black/80 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-lg border border-white/10 shadow-lg">
                {item.value}
            </div>
            <div
              className="w-3/4 rounded-t-lg transition-all duration-500 ease-out group-hover:opacity-100 opacity-80"
              style={{ 
                height: `${(item.value / maxValue) * 100}%`,
                background: `linear-gradient(to top, hsl(var(--color-primary-h), var(--color-primary-s), var(--color-primary-l)), hsla(var(--color-primary-h), var(--color-primary-s), 75%, 0.5))`
              }}
            >
            </div>
            <span className="text-xs text-gray-400 mt-2">{item.label}</span>
          </motion.div>
        ))}
      </motion.div>
    </Card>
  );
};