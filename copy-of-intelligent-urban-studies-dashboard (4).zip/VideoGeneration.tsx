
import React, { useState, useLayoutEffect, useCallback } from 'react';
import { Card } from '../components/atoms/Card';
import { Button } from '../components/atoms/Button';
import { VIDEO_ICON, MOCK_VIDEOS_DATA } from '../constants';
import { useLayout } from '../hooks/useLayout';
import { Icon } from '../components/atoms/Icon';
import { VideoType } from '../types';

const PageHeader = ({ title, subtitle }: { title: string; subtitle: string }) => (
  <div className="mb-8">
    <h1 className="text-3xl font-bold text-white">{title}</h1>
    <p className="text-gray-400 mt-2">{subtitle}</p>
  </div>
);

const VideoGenerationSidebar: React.FC<{ onGenerate: () => void }> = ({ onGenerate }) => {
    return (
      <div className="space-y-6">
        <div>
            <label htmlFor="prompt" className="form-label">پرامپت (دستور)</label>
            <textarea id="prompt" rows={5} className="form-control" placeholder="مثال: یک ربات کوچک در حال گشت و گذار در یک جنگل سرسبز..."></textarea>
        </div>
        <div>
            <label htmlFor="duration" className="form-label">مدت زمان (ثانیه)</label>
            <input type="number" id="duration" className="form-control" defaultValue={4} />
        </div>
        <div>
            <label htmlFor="motion" className="form-label">سطح حرکت</label>
            <input type="range" id="motion" min="1" max="10" defaultValue="5" className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer range-thumb" />
        </div>
        <Button onClick={onGenerate} icon={VIDEO_ICON} className="w-full">
          تولید ویدیو
        </Button>
      </div>
    );
};

const VideoCard: React.FC<{ video: VideoType, isLoading: boolean }> = ({ video, isLoading }) => (
    <Card className="aspect-video relative overflow-hidden group" padding="p-0">
        {isLoading ? (
            <div className="w-full h-full bg-white/5 animate-pulse"></div>
        ) : (
            <>
                <img src={video.thumbnailUrl} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"/>
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
                    <Button size="sm" variant="secondary">پخش</Button>
                    <Button size="sm" variant="secondary">حذف</Button>
                </div>
                <div className="absolute top-2 right-2 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
                    <Icon svg={VIDEO_ICON} className="w-3 h-3 inline me-1" /> 0:04
                </div>
            </>
        )}
    </Card>
);

const VideoGeneration: React.FC = () => {
    const { setSidebarContent } = useLayout();
    const [videos, setVideos] = useState<VideoType[]>(MOCK_VIDEOS_DATA);
    const [isLoading, setIsLoading] = useState(false);
  
    const handleGenerate = useCallback(() => {
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
            const newVideo: VideoType = {
                id: `v${Date.now()}`,
                thumbnailUrl: `https://picsum.photos/seed/${Math.random()}/500/281`,
                videoUrl: '#',
            };
            setVideos(prev => [newVideo, ...prev]);
            setIsLoading(false);
        }, 3000);
    }, []);
  
    useLayoutEffect(() => {
      setSidebarContent(<VideoGenerationSidebar onGenerate={handleGenerate} />);
      return () => setSidebarContent(null);
    }, [setSidebarContent, handleGenerate]);

    return (
        <div className="page-container">
            <PageHeader title="تولید ویدیو با هوش مصنوعی" subtitle="متن‌ها و تصاویر خود را به ویدیوهای جذاب تبدیل کنید." />
            
            <h3 className="font-bold text-white mb-4">گالری شما</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {isLoading && <VideoCard video={{id: '', thumbnailUrl: '', videoUrl: ''}} isLoading={true} />}
                {videos.map((vid) => <VideoCard key={vid.id} video={vid} isLoading={false} />)}
            </div>
    
            {videos.length === 0 && !isLoading && (
                <Card className="text-center py-16 border-dashed border-white/20">
                    <Icon svg={VIDEO_ICON} className="w-12 h-12 mx-auto text-gray-500 mb-4"/>
                    <h3 className="text-white font-bold">گالری شما خالی است</h3>
                    <p className="text-gray-400 text-sm mt-2">از پنل کناری برای ساخت اولین ویدیوی خود استفاده کنید.</p>
                </Card>
            )}
        </div>
    );
};
export default VideoGeneration;
