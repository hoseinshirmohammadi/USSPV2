
import React from 'react';
import { Icon } from '../atoms/Icon';
import { Button } from '../atoms/Button';
import { ADD_ICON, HOME_ICON, SEARCH_ICON, MENU_ICON, USER_ICON, WALLET_ICON, SETTINGS_ICON, HEADER_NAV_ITEMS } from '../../constants';
import { useAppContext } from '../../hooks/useAppContext';
import { motion } from 'framer-motion';
import { USER_PROFILE_DATA } from '../../constants';
import { NavItemType } from '../../types';

const HeaderNavItem: React.FC<{ item: NavItemType }> = ({ item }) => {
    const { currentPage, setCurrentPage } = useAppContext();
    const isActive = item.page === currentPage || (item.children && item.children.some(child => child.page === currentPage));

    if (item.children) {
        return (
            <div className="relative group">
                <button className={`flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? 'text-white' : 'text-text-secondary hover:text-white'}`}>
                    <span>{item.label}</span>
                    {item.icon}
                </button>
                <div className="absolute top-full mt-2 w-56 surface-card p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto transform group-hover:scale-100 scale-95 origin-top">
                    {item.children.map(child => (
                        <a key={child.id} onClick={() => child.page && setCurrentPage(child.page)} className="flex items-center px-3 py-2.5 text-sm rounded-md hover:bg-white/10 cursor-pointer">
                            <div className="w-5 h-5 me-3 text-primary">{child.icon}</div> {child.label}
                        </a>
                    ))}
                </div>
            </div>
        );
    }

    return (
        <button onClick={() => item.page && setCurrentPage(item.page)} className={`relative px-4 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? 'text-white' : 'text-text-secondary hover:text-white'}`}>
            <span>{item.label}</span>
            {isActive && <motion.div layoutId="header-active-underline" className="absolute bottom-0 left-2 right-2 h-0.5 bg-primary"></motion.div>}
        </button>
    );
};


const Header: React.FC = () => {
    const { toggleRightSidebar, setCurrentPage } = useAppContext();

    return (
        <header className="fixed top-0 left-0 right-0 h-16 surface-card p-0 border-b z-40 flex items-center justify-between px-4 sm:px-6 no-hover">
            {/* Left side */}
            <div className="flex items-center flex-1 gap-x-2 sm:gap-x-4">
                 <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={toggleRightSidebar} 
                    className="lg:hidden text-gray-400 hover:text-white me-3"
                    aria-label="Toggle main navigation"
                >
                    <Icon svg={MENU_ICON} className="w-6 h-6" />
                </motion.button>
                
                 <motion.div whileHover={{ scale: 1.05 }} className="flex items-center cursor-pointer" onClick={() => setCurrentPage('dashboard')}>
                   <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/30">
                     <Icon svg={HOME_ICON} className="w-5 h-5 text-white" />
                   </div>
                </motion.div>
                
                {/* Desktop Nav */}
                <nav className="hidden lg:flex items-center">
                    {HEADER_NAV_ITEMS.map(item => <HeaderNavItem key={item.id} item={item} />)}
                </nav>
            </div>

            {/* Right side */}
            <div className="flex items-center space-x-2 sm:space-x-4 rtl:space-x-reverse">
                <div className="relative hidden md:block group">
                    <input type="text" placeholder="جستجو..." className="form-control w-40 !py-1.5 focus:w-64"/>
                    <div className="absolute top-1/2 -translate-y-1/2 end-3 text-text-secondary">
                        <Icon svg={SEARCH_ICON} className="w-4 h-4" />
                    </div>
                </div>

                <Button variant="primary" size="sm" icon={ADD_ICON} onClick={() => setCurrentPage('image_generation')}>ایجاد</Button>
                
                 <div className="relative group">
                    <motion.img whileHover={{ scale: 1.1 }} src={USER_PROFILE_DATA.avatarUrl} alt="User" className="w-9 h-9 rounded-full border-2 border-primary cursor-pointer" />
                       <div className="absolute top-full mt-3 right-0 w-56 surface-card p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none group-hover:pointer-events-auto transform group-hover:scale-100 scale-95 origin-top-right">
                           <div className="p-2">
                               <p className="font-bold text-white">{USER_PROFILE_DATA.name}</p>
                               <p className="text-xs text-text-secondary">سطح {USER_PROFILE_DATA.level}</p>
                           </div>
                           <div className="my-1 h-px bg-border"></div>
                           <a onClick={() => setCurrentPage('profile')} className="flex items-center px-3 py-2.5 text-sm rounded-md hover:bg-white/10 cursor-pointer"><Icon svg={USER_ICON} className="w-5 h-5 me-3 text-primary" /> پروفایل</a>
                           <a onClick={() => setCurrentPage('wallet')} className="flex items-center px-3 py-2.5 text-sm rounded-md hover:bg-white/10 cursor-pointer"><Icon svg={WALLET_ICON} className="w-5 h-5 me-3 text-primary" /> کیف پول</a>
                           <a onClick={() => setCurrentPage('settings')} className="flex items-center px-3 py-2.5 text-sm rounded-md hover:bg-white/10 cursor-pointer"><Icon svg={SETTINGS_ICON} className="w-5 h-5 me-3 text-primary" /> تنظیمات</a>
                       </div>
                    </div>
            </div>
        </header>
    );
};

export default Header;
