
import React from 'react';
import { Card } from '../atoms/Card';
import { Icon } from '../atoms/Icon';
import { Button } from '../atoms/Button';
import { AI_ASSISTANT_ICON } from '../../constants';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div 
        className="fixed inset-0 bg-black/60 z-[99] flex items-center justify-center backdrop-blur-sm"
        onClick={onClose}
    >
        <Card 
            className="w-full max-w-2xl h-[70vh] flex flex-col transform transition-transform duration-300 scale-95 opacity-0 animate-fade-in-scale"
            padding="p-0"
            onClick={(e) => e.stopPropagation()}
        >
            <style>{`
                @keyframes fade-in-scale {
                    to {
                        transform: scale(1);
                        opacity: 1;
                    }
                }
                .animate-fade-in-scale {
                    animation: fade-in-scale 0.3s forwards ease-out;
                }
            `}</style>
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Icon svg={AI_ASSISTANT_ICON} className="w-6 h-6 text-primary" />
                    <h2 className="font-bold text-lg text-white">دستیار هوشمند</h2>
                </div>
                <button onClick={onClose} className="text-gray-400 hover:text-white">&times;</button>
            </div>

            {/* Chat Body */}
            <div className="flex-grow p-6 overflow-y-auto space-y-4">
                {/* Example Messages */}
                <div className="flex justify-start">
                    <div className="bg-gray-700 p-3 rounded-lg max-w-md">
                        <p className="text-sm">سلام! چطور میتونم در تحقیقاتتون به شما کمک کنم؟</p>
                    </div>
                </div>
                <div className="flex justify-end">
                    <div className="bg-primary p-3 rounded-lg max-w-md">
                        <p className="text-sm text-white">آخرین مقالات در مورد شهرسازی پایدار رو برام پیدا کن.</p>
                    </div>
                </div>
            </div>

            {/* Input Footer */}
            <div className="p-4 border-t border-white/10">
                <div className="relative">
                    <input 
                        type="text" 
                        placeholder="پیام خود را تایپ کنید..."
                        className="w-full bg-white/5 border border-white/10 rounded-lg py-3 px-4 pe-28 text-sm text-white focus:outline-none focus:ring-2 ring-primary"
                    />
                    <div className="absolute top-1/2 -translate-y-1/2 end-2">
                         <Button size="sm">ارسال</Button>
                    </div>
                </div>
            </div>
        </Card>
    </div>
  );
};
