import React from 'react';
import { Icon } from '../atoms/Icon';
import { CHEVRON_RIGHT_ICON, CHEVRON_LEFT_ICON, RIGHT_SIDEBAR_NAV } from '../../constants';
import { useAppContext } from '../../hooks/useAppContext';
import { motion } from 'framer-motion';
import { NavItem } from '../molecules/NavItem';

export const RightSidebar: React.FC = () => {
  const { isRtl, isRightSidebarOpen, setRightSidebarOpen, isRightSidebarCollapsed, toggleRightSidebarCollapse } = useAppContext();

  const mobileOpenClasses = 'translate-x-0 shadow-2xl';
  const mobileClosedClasses = isRtl ? 'translate-x-full' : '-translate-x-full';
  
  const sidebarWidth = isRightSidebarCollapsed ? 'lg:w-20' : 'lg:w-64';

  const positionClass = isRtl ? 'right-0' : 'left-0';

  return (
     <aside 
        id="right-sidebar"
        className={`fixed top-0 ${positionClass} h-full surface-card p-0 z-50 flex flex-col transition-all duration-300 ease-in-out lg:translate-x-0 lg:top-16 lg:h-[calc(100vh-5rem)] lg:rounded-2xl lg:m-2 ${sidebarWidth} ${isRightSidebarOpen ? mobileOpenClasses : `lg:translate-x-0 ${mobileClosedClasses}`}`}>
        
        {/* Mobile-only close button */}
        <button onClick={() => setRightSidebarOpen(false)} className={`lg:hidden absolute top-4 ${isRtl ? 'left-4' : 'right-4'} text-gray-400 hover:text-white`}>
             <Icon svg={isRtl ? CHEVRON_RIGHT_ICON : CHEVRON_LEFT_ICON} className="w-5 h-5" />
        </button>
        
        <motion.div layout="position" className="flex flex-col flex-grow min-h-0">
            <div className="flex-grow px-2 overflow-y-auto pb-4">
                 {RIGHT_SIDEBAR_NAV.map((item) => (
                    <NavItem key={item.id} item={item} isCollapsed={isRightSidebarCollapsed} />
                ))}
            </div>
            <div className="p-2 border-t border-border-color">
                <button 
                    onClick={toggleRightSidebarCollapse} 
                    className="w-full hidden lg:flex items-center justify-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors" 
                    aria-label={isRightSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                >
                    <Icon svg={isRtl ? (isRightSidebarCollapsed ? CHEVRON_LEFT_ICON : CHEVRON_RIGHT_ICON) : (isRightSidebarCollapsed ? CHEVRON_RIGHT_ICON : CHEVRON_LEFT_ICON)} className="w-5 h-5" />
                </button>
            </div>
        </motion.div>
    </aside>
  );
};