
import React from 'react';

interface IconProps {
  svg: string;
  className?: string;
}

export const Icon: React.FC<IconProps> = ({ svg, className = 'w-6 h-6' }) => {
  return (
    <span
      className={className}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
};