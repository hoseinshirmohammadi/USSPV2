
import React from 'react';
import { RecentActivityType } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';

interface ActivityItemProps {
  activity: RecentActivityType;
}

export const ActivityItem: React.FC<ActivityItemProps> = ({ activity }) => {
  const { setCurrentPage } = useAppContext();
  const isClickable = !!activity.page;

  const handleClick = () => {
    if (activity.page) {
      setCurrentPage(activity.page);
    }
  };

  return (
    <div 
        className={`flex items-center space-x-4 rtl:space-x-reverse py-2.5 px-2 rounded-lg ${isClickable ? 'cursor-pointer hover:bg-white/5' : ''}`}
        onClick={handleClick}
    >
        <div className="p-2 bg-gray-700/50 rounded-lg">
            {activity.icon}
        </div>
        <div className="flex-grow">
            <p className="font-medium text-white text-sm">{activity.title}</p>
            <p className="text-xs text-gray-400">{activity.date}</p>
        </div>
    </div>
  );
};