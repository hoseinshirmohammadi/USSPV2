
import React, { createContext, useState } from 'react';

interface LayoutContextType {
  sidebarContent: React.ReactNode;
  setSidebarContent: (content: React.ReactNode) => void;
}

export const LayoutContext = createContext<LayoutContextType | undefined>(undefined);

export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarContent, setSidebarContent] = useState<React.ReactNode>(null);

  return (
    <LayoutContext.Provider value={{ sidebarContent, setSidebarContent }}>
      {children}
    </LayoutContext.Provider>
  );
};
