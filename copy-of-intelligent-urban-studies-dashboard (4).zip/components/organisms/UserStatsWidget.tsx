
import React from 'react';
import { Icon } from '../atoms/Icon';
import { USER_PROFILE_DATA, WALLET_SUMMARY_DATA, WALLET_ICON, STATS_ICON_2 } from '../../constants';
import { useAppContext } from '../../hooks/useAppContext';

export const UserStatsWidget: React.FC = () => {
    const { setCurrentPage } = useAppContext();
    const levelProgress = (USER_PROFILE_DATA.points % 1000) / 10; // Example progress
    const strokeWidth = 8;
    const radius = 50;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (levelProgress / 100) * circumference;

    return (
        <div 
            className="p-4 user-stats-widget-container cursor-pointer group border-b border-border"
            onClick={() => setCurrentPage('profile')}
        >
            <div className="flex flex-col items-center text-center">
                 <div className="relative w-28 h-28 mb-4">
                     <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                         <circle
                             className="text-white/10"
                             stroke="currentColor"
                             strokeWidth={strokeWidth}
                             fill="transparent"
                             r={radius}
                             cx="60"
                             cy="60"
                         />
                         <circle
                             className="text-primary transition-all duration-500 group-hover:drop-shadow-[0_0_5px_var(--color-primary)]"
                             stroke="currentColor"
                             strokeWidth={strokeWidth}
                             fill="transparent"
                             r={radius}
                             cx="60"
                             cy="60"
                             strokeLinecap="round"
                             style={{ strokeDasharray: circumference, strokeDashoffset }}
                             />
                     </svg>
                     <img src={USER_PROFILE_DATA.avatarUrl} alt={USER_PROFILE_DATA.name} className="absolute inset-0 m-auto w-20 h-20 rounded-full border-4 border-transparent group-hover:scale-105 transition-transform" />
                 </div>
                 <h3 className="font-bold text-lg text-white group-hover:text-primary transition-colors">{USER_PROFILE_DATA.name}</h3>
                 <p className="text-sm text-gray-400 mb-4">سطح {USER_PROFILE_DATA.level}</p>

                 <div className="user-stats-widget-details">
                     <div className="flex-1 flex items-center text-sm p-2 bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors">
                        <Icon svg={WALLET_ICON} className="w-5 h-5 text-primary me-2"/>
                        <span className="text-gray-300">موجودی:</span>
                        <span className="font-bold text-white ms-auto">{WALLET_SUMMARY_DATA.balance.toLocaleString()}</span>
                     </div>
                      <div className="flex-1 flex items-center text-sm p-2 bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors">
                        <Icon svg={STATS_ICON_2} className="w-5 h-5 text-primary me-2"/>
                        <span className="text-gray-300">امتیاز:</span>
                        <span className="font-bold text-white ms-auto">{USER_PROFILE_DATA.points.toLocaleString()}</span>
                     </div>
                 </div>
            </div>
        </div>
    );
};
