import React, { useState, useRef, useEffect } from 'react';
import { Card } from '../components/atoms/Card';
import { PERSONA_CHAT_DATA, SEND_ICON } from '../constants';
import { PersonaType, MessageType } from '../types';
import { Button } from '../components/atoms/Button';
import { Icon } from '../components/atoms/Icon';

const PersonaSelector: React.FC<{ onSelect: (persona: PersonaType) => void; activePersonaId?: string }> = ({ onSelect, activePersonaId }) => (
    <div className="space-y-3">
        {PERSONA_CHAT_DATA.map(persona => (
            <button key={persona.id} onClick={() => onSelect(persona)} className={`w-full flex items-center p-3 rounded-lg text-right transition-colors duration-200 ${activePersonaId === persona.id ? 'bg-primary/20' : 'hover:bg-white/10'}`}>
                <img src={persona.avatarUrl} alt={persona.name} className="w-12 h-12 rounded-full"/>
                <div className="me-4">
                    <p className="font-bold text-white">{persona.name}</p>
                    <p className="text-xs text-gray-400">{persona.title}</p>
                </div>
            </button>
        ))}
    </div>
);

const ChatWindow: React.FC<{ persona: PersonaType, messages: MessageType[], onSendMessage: (text: string) => void }> = ({ persona, messages, onSendMessage }) => {
    const [inputValue, setInputValue] = useState('');
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }

    useEffect(scrollToBottom, [messages]);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
        }
    }, [inputValue]);
    
    const handleSend = () => {
        if (inputValue.trim()) {
            onSendMessage(inputValue.trim());
            setInputValue('');
        }
    };
    
    const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="flex flex-col h-full">
             <div className="flex-grow p-6 overflow-y-auto space-y-4">
                {messages.map((message) => (
                    <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`flex gap-3 items-start ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                            {message.sender === 'persona' && <img src={persona.avatarUrl} className="w-8 h-8 rounded-full" alt="persona" />}
                            <div className={`chat-bubble ${message.sender === 'user' ? 'chat-bubble-user' : 'chat-bubble-persona'}`}>
                                <p>{message.text}</p>
                            </div>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
    
            <div className="p-4 border-t border-white/10">
                <div className="relative flex items-end">
                    <textarea 
                        ref={textareaRef}
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder={`پیامی برای ${persona.name} بنویسید...`}
                        className="form-control pe-12 autoresize-textarea max-h-32"
                        rows={1}
                    />
                    <button onClick={handleSend} className="absolute bottom-3 end-3 text-primary hover:text-white transition-colors">
                        <Icon svg={SEND_ICON} className="w-6 h-6"/>
                    </button>
                </div>
            </div>
        </div>
    );
};

const PersonaChat: React.FC = () => {
    const [selectedPersona, setSelectedPersona] = useState<PersonaType>(PERSONA_CHAT_DATA[0]);
    const [chatHistories, setChatHistories] = useState<Record<string, MessageType[]>>(() => {
        const initialHistories: Record<string, MessageType[]> = {};
        PERSONA_CHAT_DATA.forEach(p => {
            initialHistories[p.id] = [{ id: 'greeting-1', text: p.greeting, sender: 'persona' }];
        });
        return initialHistories;
    });

    const handleSendMessage = (text: string) => {
        const newUserMessage: MessageType = {
            id: `msg-${Date.now()}`,
            text,
            sender: 'user',
        };
        const updatedHistory = [...chatHistories[selectedPersona.id], newUserMessage];
        setChatHistories(prev => ({...prev, [selectedPersona.id]: updatedHistory}));
        
        // Simulate AI response
        setTimeout(() => {
            const aiResponse: MessageType = {
                id: `msg-${Date.now() + 1}`,
                text: `پاسخ شبیه‌سازی شده برای: "${text.substring(0, 20)}..."`,
                sender: 'persona',
            };
            setChatHistories(prev => ({...prev, [selectedPersona.id]: [...updatedHistory, aiResponse]}));
        }, 1500);
    };

    return (
    <div className="page-container">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 h-[calc(100vh-10rem)]">
            <Card className="lg:col-span-1 overflow-y-auto" padding="p-4">
                <h2 className="font-bold text-lg text-white mb-4">انتخاب شخصیت</h2>
                <PersonaSelector onSelect={setSelectedPersona} activePersonaId={selectedPersona.id} />
            </Card>
            <Card className="lg:col-span-3 flex flex-col" padding="p-0">
                <ChatWindow 
                    persona={selectedPersona} 
                    messages={chatHistories[selectedPersona.id] || []}
                    onSendMessage={handleSendMessage}
                />
            </Card>
        </div>
    </div>
  );
};
export default PersonaChat;