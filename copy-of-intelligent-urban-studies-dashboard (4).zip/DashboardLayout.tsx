
import React from 'react';
import Header from '../organisms/Header';
import { RightSidebar } from '../organisms/RightSidebar';
import { LeftSidebar } from '../organisms/LeftSidebar';
import { useAppContext } from '../../hooks/useAppContext';
import { LayoutProvider } from '../../context/LayoutContext';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { isRtl, isRightSidebarCollapsed } = useAppContext();
  
  const mainMargin = isRtl
    ? (isRightSidebarCollapsed ? 'lg:mr-[6rem] lg:ml-[19rem]' : 'lg:mr-[17rem] lg:ml-[19rem]')
    : (isRightSidebarCollapsed ? 'lg:ml-[6rem] lg:mr-[19rem]' : 'lg:ml-[17rem] lg:mr-[19rem]');

  return (
    <LayoutProvider>
      <div className="min-h-screen">
        <Header />
        <RightSidebar />
        <LeftSidebar />
        
        <main className={`relative transition-all duration-300 ease-in-out pt-16 min-h-screen ${mainMargin}`}>
            <div className="flex-grow min-w-0">
                {children}
            </div>
        </main>
        
      </div>
    </LayoutProvider>
  );
};

export default DashboardLayout;
