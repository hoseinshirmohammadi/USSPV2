
import React, { useState } from 'react';
import { Icon } from '../atoms/Icon';
import { CHAT_ICON, LANGUAGE_ICON, THEME_ICON, ADD_ICON } from '../../constants';
import { useAppContext } from '../../hooks/useAppContext';
import { ThemeSwitcher } from './ThemeSwitcher';

export const Footer: React.FC = () => {
  const { setChatOpen, toggleDirection, handleThemeChange, isRtl } = useAppContext();
  const [isMenuOpen, setMenuOpen] = useState(false);

  const menuButtonClass = "w-12 h-12 bg-gray-700/60 backdrop-blur-sm rounded-full flex items-center justify-center text-white shadow-lg hover:bg-gray-600 transition-all duration-300";

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="relative flex flex-col items-center space-y-3">
        
        {/* Collapsed menu items */}
        <div 
          className={`transition-all duration-300 ease-in-out transform ${isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
        >
          <div className="flex flex-col items-center space-y-3">
             <div className="group relative">
                <button className={menuButtonClass}>
                    <Icon svg={THEME_ICON} className="w-6 h-6" />
                </button>
                <div className="absolute bottom-1/2 translate-y-1/2 right-full mr-3 p-2 bg-gray-800/80 backdrop-blur-md rounded-full flex space-x-2 rtl:space-x-reverse opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-300 pointer-events-none group-hover:pointer-events-auto group-focus-within:pointer-events-auto">
                    <ThemeSwitcher onThemeChange={handleThemeChange} />
                </div>
            </div>
             <button onClick={toggleDirection} className={menuButtonClass} aria-label="Toggle Language Direction">
              <Icon svg={LANGUAGE_ICON} className="w-6 h-6" />
            </button>
             <button onClick={() => setChatOpen(true)} className={menuButtonClass} aria-label="Open AI Assistant">
              <Icon svg={CHAT_ICON} className="w-7 h-7" />
            </button>
          </div>
        </div>

        {/* Main FAB */}
        <button
            onClick={() => setMenuOpen(prev => !prev)}
            className={`w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white shadow-lg hover:scale-105 transition-all duration-300 ${isMenuOpen ? 'rotate-45' : ''}`}
            aria-label="Toggle Menu"
        >
            <Icon svg={ADD_ICON} className="w-8 h-8" />
        </button>
      </div>
    </footer>
  );
};