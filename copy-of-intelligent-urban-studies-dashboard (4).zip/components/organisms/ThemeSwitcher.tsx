
import React from 'react';

interface ThemeSwitcherProps {
  onThemeChange: (hsl: { h: number; s: number; l: number }) => void;
}

const themes = [
  { name: 'blue', hsl: { h: 217, s: 91, l: 60 }, colorClass: 'bg-blue-500' },
  { name: 'purple', hsl: { h: 259, s: 85, l: 66 }, colorClass: 'bg-purple-500' },
  { name: 'green', hsl: { h: 142, s: 71, l: 45 }, colorClass: 'bg-green-500' },
  { name: 'orange', hsl: { h: 34, s: 97, l: 63 }, colorClass: 'bg-orange-500' },
];

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ onThemeChange }) => {
  return (
    <>
        {themes.map(theme => (
            <button
                key={theme.name}
                onClick={() => onThemeChange(theme.hsl)}
                className={`w-6 h-6 rounded-full ${theme.colorClass} ring-2 ring-transparent hover:ring-white/50 transition-all duration-200 hover:scale-110`}
                aria-label={`Switch to ${theme.name} theme`}
            />
        ))}
    </>
  );
};