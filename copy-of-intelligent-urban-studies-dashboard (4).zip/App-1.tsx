import React, { useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useAppContext } from './hooks/useAppContext';
import DashboardLayout from './components/templates/DashboardLayout';
import { ChatModal } from './components/organisms/ChatModal';

import Dashboard from './pages/Dashboard';
import ImageGeneration from './pages/ImageGeneration';
import VideoGeneration from './pages/VideoGeneration';
import Academy from './pages/Academy';
import Wallet from './pages/Wallet';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import PersonaChat from './pages/PersonaChat';
import NotFound from './pages/NotFound';
import WritingCenter from './pages/WritingCenter';
import TranslatorPro from './pages/TranslatorPro';
import TerminologyBook from './pages/TerminologyBook';
import PlagiarismChecker from './pages/PlagiarismChecker';
import ResearchToolkit from './pages/ResearchToolkit';
import DataLab from './pages/DataLab';
import DigitalLibrary from './pages/DigitalLibrary';
import Surveys from './pages/Surveys';
import AiCenter from './pages/AiCenter';
import ResearchManager from './pages/ResearchManager';
import Radiocity from './pages/Radiocity';
import Store from './pages/Store';
import Publications from './pages/Publications';
import About from './pages/About';
import Contact from './pages/Contact';

const pageComponents: { [key: string]: React.FC } = {
  dashboard: Dashboard,
  image_generation: ImageGeneration,
  video_generation: VideoGeneration,
  academy: Academy,
  wallet: Wallet,
  profile: Profile,
  settings: Settings,
  persona_chat: PersonaChat,
  writing_center: WritingCenter,
  translator_pro: TranslatorPro,
  terminology_book: TerminologyBook,
  plagiarism_checker: PlagiarismChecker,
  research_toolkit: ResearchToolkit,
  data_lab: DataLab,
  digital_library: DigitalLibrary,
  surveys: Surveys,
  ai_center: AiCenter,
  research_manager: ResearchManager,
  radiocity: Radiocity,
  store: Store,
  publications: Publications,
  about: About,
  contact: Contact,
};

const App: React.FC = () => {
  const {
    isRtl,
    isChatOpen,
    setChatOpen,
    currentPage,
  } = useAppContext();

  React.useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.body.className = `page-${currentPage}`;
  }, [isRtl, currentPage]);

  const CurrentPageComponent = pageComponents[currentPage] || NotFound;

  return (
    <div className={`min-h-screen relative`}>
      <DashboardLayout>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <CurrentPageComponent />
          </motion.div>
        </AnimatePresence>
      </DashboardLayout>

      <ChatModal isOpen={isChatOpen} onClose={() => setChatOpen(false)} />
    </div>
  );
};

export default App;