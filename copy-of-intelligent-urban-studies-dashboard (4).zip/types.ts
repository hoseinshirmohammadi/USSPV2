
import React from 'react';

export type Page = 
  | 'dashboard' 
  | 'image_generation' 
  | 'video_generation' 
  | 'academy' 
  | 'wallet' 
  | 'profile' 
  | 'settings'
  | 'persona_chat'
  | 'writing_center'
  | 'translator_pro'
  | 'terminology_book'
  | 'plagiarism_checker'
  | 'research_toolkit'
  | 'data_lab'
  | 'digital_library'
  | 'surveys'
  | 'ai_center'
  | 'research_manager'
  | 'radiocity'
  | 'store'
  | 'publications'
  | 'about'
  | 'contact';

export interface NavItemType {
  id: string;
  label: string;
  icon?: React.ReactElement;
  active?: boolean;
  isSectionTitle?: boolean;
  children?: NavItemType[];
  page?: Page;
}

export interface StatCardType {
  id:string;
  title: string;
  value: string;
  change: string;
  changeType: 'increase' | 'decrease';
  icon: React.ReactNode;
  color: string;
}

export interface QuickActionCardType {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  page?: Page;
}

export interface ActiveTaskType {
  id: string;
  title: string;
  project: string;
  progress: number;
}

export interface RecentActivityType {
  id: string;
  title: string;
  date: string;
  icon: React.ReactNode;
  description?: string;
  page?: Page;
}

export interface ChartDataType {
    label: string;
    value: number;
}

export interface CourseType {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  imageUrl: string;
  tag: string;
}

export interface WalletSummaryType {
    balance: number;
    currency: string;
    spentThisMonth: number;
}

export interface TransactionType {
    id: string;
    description: string;
    date: string;
    amount: number;
    type: 'credit' | 'debit';
}

export interface PersonaType {
    id: string;
    name: string;
    title: string;
    avatarUrl: string;
    expertise: string;
    greeting: string;
}

export interface AchievementType {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface UserProfileType {
  name: string;
  level: number;
  points: number;
  avatarUrl: string;
  joinDate: string;
  bio: string;
  title: string;
  organization: string;
  website: string;
  skills: string[];
  achievements: AchievementType[];
}

export interface VideoType {
    id: string;
    thumbnailUrl: string;
    videoUrl: string;
}

export interface MessageType {
    id: string;
    text: string;
    sender: 'user' | 'persona';
}
