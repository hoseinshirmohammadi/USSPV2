import React from 'react';
import { Icon } from '../atoms/Icon';
import { CHEVRON_LEFT_ICON } from '../../constants';
import { useAppContext } from '../../hooks/useAppContext';
import { useLayout } from '../../hooks/useLayout';
import { AnimatePresence, motion } from 'framer-motion';
import { UserStatsWidget } from './UserStatsWidget';
import { RecentActivityWidget } from './RecentActivityWidget';
import { SidebarChatWidget } from './SidebarChatWidget';


export const LeftSidebar: React.FC = () => {
    const { isRtl, isLeftSidebarOpen, setLeftSidebarOpen } = useAppContext();
    const { sidebarContent } = useLayout();

    const mobileOpenClasses = 'translate-x-0 shadow-2xl';
    const mobileClosedClasses = isRtl ? '-translate-x-full' : 'translate-x-full';
  
    return (
        <aside 
            id="left-sidebar"
            className={`fixed top-0 ${isRtl ? 'left-0' : 'right-0'} h-full surface-card p-0 z-40 flex flex-col transition-transform duration-300 ease-in-out w-72 lg:top-16 lg:h-[calc(100vh-5rem)] lg:rounded-2xl lg:m-2 lg:translate-x-0
            ${isLeftSidebarOpen ? mobileOpenClasses : `lg:translate-x-0 ${mobileClosedClasses}`}`}
        >
            <div className="w-full h-full flex flex-col relative">
                <button 
                    onClick={() => setLeftSidebarOpen(false)} 
                    className={`lg:hidden absolute top-4 ${isRtl ? 'left-4' : 'right-4'} text-gray-400 hover:text-white z-10`}
                >
                    <Icon svg={CHEVRON_LEFT_ICON} className={`w-5 h-5 ${isRtl ? '' : 'rotate-180'}`} />
                </button>
                
                {/* Always-on User Profile Widget */}
                <UserStatsWidget />

                <div className="flex-grow flex flex-col min-h-0">
                    <div className="flex-grow p-2 overflow-y-auto">
                    <AnimatePresence mode="wait">
                            <motion.div
                                key={useAppContext().currentPage} // Re-render content on page change
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -10 }}
                                transition={{ duration: 0.3 }}
                            >
                                {sidebarContent ? (
                                    sidebarContent
                                ) : (
                                    <div className="space-y-4">
                                        <RecentActivityWidget />
                                        <SidebarChatWidget />
                                    </div>
                                )}
                            </motion.div>
                        </AnimatePresence>
                    </div>
                </div>
            </div>
        </aside>
  );
};