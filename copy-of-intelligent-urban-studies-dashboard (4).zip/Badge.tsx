
import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  color?: 'primary' | 'green' | 'red' | 'yellow' | 'blue' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  color = 'primary',
  size = 'md',
  className = '',
}) => {
  const baseClasses = 'inline-flex items-center font-semibold rounded-full border';

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-0.5 text-sm',
  };

  const colorClasses = {
    primary: 'bg-primary/20 text-blue-300 border-primary/30',
    green: 'bg-green-500/10 text-green-300 border-green-500/20',
    red: 'bg-red-500/10 text-red-300 border-red-500/20',
    yellow: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/20',
    blue: 'bg-sky-500/10 text-sky-300 border-sky-500/20',
    gray: 'bg-gray-500/10 text-gray-300 border-gray-500/20',
  };

  return (
    <span className={`${baseClasses} ${sizeClasses[size]} ${colorClasses[color]} ${className}`}>
      {children}
    </span>
  );
};
